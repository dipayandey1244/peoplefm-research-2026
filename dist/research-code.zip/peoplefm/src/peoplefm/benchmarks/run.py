"""Offline binary classification benchmark. Final test set is never used in selection."""
import argparse, hashlib, json, os, platform, time, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (roc_auc_score, average_precision_score, balanced_accuracy_score,
    recall_score, precision_score, f1_score, brier_score_loss, precision_recall_curve)
from sklearn.model_selection import train_test_split, GridSearchCV, RepeatedStratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

def ece(y,p,bins=10):
    edges=np.linspace(0,1,bins+1); ids=np.minimum(np.digitize(p,edges[1:-1]),bins-1)
    return float(sum(np.mean(ids==i)*abs(np.mean(p[ids==i])-np.mean(y[ids==i])) for i in range(bins) if np.any(ids==i)))

def metrics(y,p):
    pred=p>=0.5
    return dict(roc_auc=float(roc_auc_score(y,p)), average_precision=float(average_precision_score(y,p)),
        balanced_accuracy=float(balanced_accuracy_score(y,pred)), recall=float(recall_score(y,pred,zero_division=0)),
        precision=float(precision_score(y,pred,zero_division=0)), f1=float(f1_score(y,pred,zero_division=0)),
        brier=float(brier_score_loss(y,p)), ece=ece(y,p))

def interval(y,p,n,seed):
    # Stratified row bootstrap conditions on observed class counts. It does not account for training variability.
    rng=np.random.default_rng(seed); idx=[np.flatnonzero(y==v) for v in [0,1]]; samples={k:[] for k in metrics(y,p)}
    for _ in range(n):
        sel=np.concatenate([rng.choice(a,len(a),replace=True) for a in idx]); m=metrics(y[sel],p[sel])
        for k,v in m.items(): samples[k].append(v)
    return {k:[float(x) for x in np.quantile(v,[.025,.975])] for k,v in samples.items()}

def build(name,seed):
    num=Pipeline([('impute',SimpleImputer(strategy='median')),('scale',StandardScaler())])
    cat=Pipeline([('impute',SimpleImputer(strategy='most_frequent')),('encode',OneHotEncoder(handle_unknown='ignore'))])
    prep=ColumnTransformer([('num',num,make_column_selector(dtype_include=np.number)),('cat',cat,make_column_selector(dtype_exclude=np.number))])
    if name=='logistic': model=LogisticRegression(max_iter=2000,random_state=seed); grid={'model__C':[0.1,1,10]}
    elif name=='random_forest': model=RandomForestClassifier(random_state=seed,n_jobs=1); grid={'model__n_estimators':[150], 'model__min_samples_leaf':[1,5,15]}
    elif name=='mlp': model=MLPClassifier(random_state=seed,max_iter=400,early_stopping=True); grid={'model__hidden_layer_sizes':[(32,),(64,32)],'model__alpha':[0.001,0.1]}
    elif name=='xgboost':
        from xgboost import XGBClassifier
        model=XGBClassifier(n_estimators=150, random_state=seed,n_jobs=1,verbosity=0)
        grid={'model__max_depth':[2,4],'model__learning_rate':[0.05,0.1]}
    elif name=='lightgbm':
        from lightgbm import LGBMClassifier
        model=LGBMClassifier(n_estimators=150,random_state=seed,n_jobs=1,verbosity=-1)
        grid={'model__num_leaves':[7,15],'model__learning_rate':[0.05,0.1]}
    elif name=='catboost':
        from catboost import CatBoostClassifier
        model=CatBoostClassifier(iterations=150,random_seed=seed,thread_count=1,verbose=False,allow_writing_files=False)
        grid={'model__depth':[3,5],'model__learning_rate':[0.05,0.1]}
    else: raise ValueError('Unsupported model: '+name)
    return Pipeline([('prep',prep),('model',model)]),grid

def run(c):
    path=Path(c['dataset']); raw=path.read_bytes(); df=pd.read_csv(path); target=c['target']
    if df[target].isna().any(): raise ValueError('Missing targets are not supported')
    if df[target].nunique()!=2 or c['positive_label'] not in df[target].unique(): raise ValueError('Expected binary target with explicit positive label')
    y=(df[target]==c['positive_label']).astype(int).to_numpy(); X=df.drop(columns=[target]+c.get('drop_columns',[]),errors='ignore')
    if not len(X.columns): raise ValueError('No features remain')
    a,b=train_test_split(np.arange(len(df)),test_size=c['test_size'],stratify=y,random_state=c['seed'])
    out=Path(c['output']); out.mkdir(parents=True,exist_ok=True)
    audit={'rows':len(df),'columns':len(df.columns),'missing_cells':int(df.isna().sum().sum()),'duplicate_rows':int(df.duplicated().sum()),'target_counts':df[target].value_counts().to_dict(),'sha256':hashlib.sha256(raw).hexdigest(),'classification':c['data_classification'],'features_used':list(X.columns),'dropped':c.get('drop_columns',[]),'test_rows':len(b)}
    results=[]; curves={}; predictions={'row_index':b.tolist(),'label':y[b].tolist()}
    cv=RepeatedStratifiedKFold(n_splits=c['cv_splits'],n_repeats=c['cv_repeats'],random_state=c['seed'])
    for name in c['models']:
        pipe,grid=build(name,c['seed']); search=GridSearchCV(pipe,grid,scoring='average_precision',cv=cv,n_jobs=1,refit=True,error_score='raise')
        start=time.perf_counter(); search.fit(X.iloc[a],y[a]); fit=time.perf_counter()-start
        start=time.perf_counter(); prob=search.predict_proba(X.iloc[b])[:,1]; latency=time.perf_counter()-start
        m=metrics(y[b],prob); precision,recall,threshold=precision_recall_curve(y[b],prob)
        results.append({'model':name,'status':'EXECUTED','metrics':m,'bootstrap_95_ci':interval(y[b],prob,c['bootstrap_repeats'],c['seed']), 'best_params':search.best_params_,'cv_mean_average_precision':float(search.best_score_),'fit_and_search_seconds':fit,'test_inference_seconds':latency,'threshold':0.5})
        curves[name]={'precision':precision.tolist(),'recall':recall.tolist(),'thresholds':threshold.tolist()}; predictions[name]=prob.tolist()
    summary={'audit':audit,'protocol':{'split':'stratified held-out test; repeated stratified CV on training only','threshold':'fixed 0.5 before test','bootstrap':'stratified test-row bootstrap, conditional on fitted model','warning':'Not a temporal or external validation. CIs exclude training and tuning variation.','config':c},'environment':{'python':platform.python_version(),'platform':platform.platform(),'sklearn':sklearn.__version__,'numpy':np.__version__,'pandas':pd.__version__},'results':results}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)); (out/'pr_curves.json').write_text(json.dumps(curves));
    # Predictions are sensitive for real datasets. Explicit opt-in is required.
    if c.get('save_predictions',False): (out/'predictions.json').write_text(json.dumps(predictions))
    print(json.dumps(summary,indent=2)); return summary

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--config',required=True); args=parser.parse_args()
    run(json.loads(Path(args.config).read_text()))
if __name__=='__main__': main()

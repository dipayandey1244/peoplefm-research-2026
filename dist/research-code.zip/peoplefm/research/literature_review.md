# Literature review — preliminary evidence map

For the historical development of HR, organizational psychology and analytics, see [the companion historical review](hr_psychology_analytics_history.md).

**Coverage is incomplete.** This is a targeted primary-source evidence map, not the comprehensive 2024–2026 systematic review requested. Search and source inspection were limited; a formal search strategy, full-text extraction, HR analytics studies, employment governance, LimiX, relational models, and version-specific licensing remain outstanding. The registry records unverified fields as such. No published result is a PeopleFM measurement.

## Tabular foundation models

[TabPFN v2](https://www.nature.com/articles/s41586-024-08328-6) demonstrated prior-data fitting for small tabular datasets. [TabICL](https://proceedings.mlr.press/v267/qu25d.html) uses column/row representations followed by in-context learning; its authors report good predictive performance and speed on TALENT. [TabICLv2](https://proceedings.mlr.press/v306/qu26a.html) adds synthetic task generation, architectural and optimization changes, reporting improvements on TabArena and TALENT. Those are authors' claims on their protocols, not a workforce-specific comparison.

[TabFM](https://arxiv.org/abs/2609.37959) describes synthetic-table pretraining and zero-shot in-context inference; [official code](https://github.com/google-research/tabfm) is available. [Mitra-v2](https://arxiv.org/abs/2609.04540) describes synthetic pretraining of a 2D transformer and reports releasing weights and code under Apache-2.0; verify actual assets. [TabPFN-3.5](https://arxiv.org/abs/2609.17895) is a technical report; its [official repository](https://github.com/PriorLabs/TabPFN) says newer weights require account login and license acceptance. These candidates were not executed. Models' claimed benchmark positions are sensitive to the version, tuning budget, datasets and metric; they do not establish superiority on HR data.

## Conventional deep learning and transfer

[TabM](https://arxiv.org/abs/2410.24210) uses parameter-efficient MLP ensembling and is an important strong baseline. Simple models deserve comparable tuning budgets. In-context prediction adapts to labeled context without gradient updates; it does not by itself establish that a reusable workforce representation has been learned. Claims about cross-task representation require genuinely distinct labels, a shared pretrained encoder and controlled baselines. Temporal transfer requires timestamps and a prospective split; a random row split is insufficient.

## Data and responsible interpretation

The [UCI absenteeism dataset](https://archive.ics.uci.edu/dataset/445/absenteeism) documents 740 observations from a Brazilian courier company in 2007–2010, CC BY 4.0. It is longitudinal in source description, but employee grouping and usable temporal granularity need file-level audit; it is not an attrition target. [BLS JOLTS](https://www.bls.gov/jlt/) concerns aggregate labor-market measures and cannot validate individual predictions. Small, repeated or clustered observations demand group-aware splits and cluster uncertainty. Excluding protected columns does not remove proxies; calibration and subgroup performance must be assessed lawfully with sufficient group sizes, and data leakage and privacy remain concerns. No decision-use or causal claims follow from predictive metrics.

## Evidence status

Peer-reviewed: Nature TabPFN v2, ICML TabICL and TabICLv2. Preprint or technical report: TabM, TabFM, Mitra-v2 and TabPFN-3.5. Model providers' reported findings are not local reproductions. See `paper_registry.csv` for source links, available architecture notes, and explicit unknowns. No systematic recall or completeness claim is made.

# PeopleFM: A protocol for evidence on transferable workforce models

**Status: PROPOSED.** Exploratory comparisons have now been executed; see `experimental_results.md`. This article is a research protocol and interim report, not a publication of findings.

## Abstract

We ask whether pretrained tabular models improve workforce prediction under limited labels, distribution shift and multiple tasks. Available evidence in this project does not yet answer the question. We implement a leak-resistant classification benchmark scaffold and document missing data, model access and evaluation limitations.

## Method

For a binary task, isolate a stratified final test set before tuning. Fit imputation, one-hot encoding and scaling within each training fold, using repeated stratified CV to select hyperparameters by average precision. Fit the chosen model on training data, then evaluate the held-out test once using ROC-AUC, average precision, balanced accuracy, precision, recall, F1, Brier score and ten-bin expected calibration error. A fixed threshold of 0.5 avoids test-set threshold selection. A stratified bootstrap estimates conditional test-sample uncertainty; it does not include training variability. Data with repeated people or organizations instead require grouped or temporal validation and cluster-aware uncertainty.

## Results and ablations

**EXECUTED:** comparisons on the fictional IBM sample and a bounded sample of the TabArena job-change-intention task; see `experimental_results.md` and the generated artifacts. Cross-task studies and ablations remain blocked. A non-workforce software smoke test verifies execution and must not be interpreted as HR evidence. Further foundation-model comparisons, shift detection and data-efficiency experiments are pending.

## Representation proposal

If independently sourced, time-stamped, multi-outcome data and baselines justify it, a shared encoder could map features available at time t to z = Eθ(x≤t, o≤t), with task head ŷk = gφk(z). This is a proposal, not an implemented or pretrained foundation model. Any masked, contrastive or temporal objective would require a justified data-generating setting and controlled ablation. A single fictional snapshot cannot establish transfer.

## Risks and reproducibility

Prediction is not causal inference. Employment data carry privacy and discrimination risks, including proxy attributes; no individual employment decision use is authorized. Data provenance, feature timing, licenses, uncertainty and limitations must accompany any future results. See `docs/limitations.md`, `datasets/registry.yaml` and the literature registry for the current audit.

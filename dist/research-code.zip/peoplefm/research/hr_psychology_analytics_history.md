# From managing labor to understanding work: a history of HR, psychology and analytics

**Scope and status.** This is a narrative evidence map through the project cutoff of 22 November 2026, not an exhaustive systematic review or a universal history. It follows selected developments, with a US/European emphasis in the sources, alongside international labor standards. Work and its organization are much older and more geographically diverse than modern HRM; chronology is not a claim that each period replaced the last. Sources include primary research, statutory and institutional records, and historical syntheses. The links support particular historical examples, not every possible region or workplace.

## A shared thread

Organizations have always coordinated work, but modern personnel management and industrial-organizational psychology are distinct historical developments. The recurring questions are: how is work organized, what do people experience, who has power, what is measured, and who benefits? This project brings psychology and analytics together: psychological theory helps define meaningful constructs and plausible mechanisms, while statistics can test measurements and relationships. Neither prediction nor an impressive model reveals a person's motivation, proves causality, or substitutes for employee voice and labor rights.

## Before 1800 — Before industrial HR

Work was organized through households, agriculture, craft, trade, armies and public administration, with apprenticeship, obligations, hierarchy and coercion varying across societies. These arrangements are antecedents to workforce coordination, not a single origin of modern HR. [ILO historical context](https://www.ilo.org/sites/default/files/wcmsp5/groups/public/%40dgreports/%40dcomm/%40publ/documents/publication/wcms_104643.pdf).

**Psychology and work.** Learning, belonging, authority and fairness already mattered, even though modern organizational psychology did not yet exist.

**Measurement and analytics.** Records, wages and production counts are early forms of administration; surviving records tell us more about institutions than individual experience.

## 1800–1890s — Industrialization & labor organization

Factory growth made hiring, wages, working time, safety and discipline recurring organizational problems. Workers organized collectively, while reforms and welfare practices developed unevenly. [ILO history](https://www.ilo.org/publications/international-labour-organization-and-quest-social-justice-1919-2009).

**Psychology and work.** Fatigue, skill and the lived effects of work entered public debate alongside power, inequality and collective voice.

**Measurement and analytics.** Payroll and headcounts made labor visible in administrative records, but what was counted reflected employers’ priorities.

## 1890s–1910s — Efficiency & early applied psychology

Scientific management and time-and-motion studies sought to organize tasks and standardize work. Early industrial psychologists applied experimental methods to selection and work. [History of industrial-organizational psychology](https://academic.oup.com/edited-volume/36330/chapter/318704027).

**Psychology and work.** Attention, aptitude, fatigue and human differences became subjects of systematic study. Efficiency-oriented methods could overlook autonomy and workers’ knowledge.

**Measurement and analytics.** Timing tasks and assessing job requirements linked measurement to management. Measures need job relevance, reliability and fairness.

## 1910s–1920s — War, testing & labor standards

World War I accelerated testing, classification and training in several countries. The ILO was created in 1919; its first conference addressed working time and other labor standards. [ILO original records](https://www.ilo.org/resource/news/digital-collections-first-international-labour-conference-and-governing).

**Psychology and work.** Assessment and classification grew, but early tests were also shaped by language, cultural assumptions and discriminatory institutions.

**Measurement and analytics.** Large-scale scores and personnel records enabled comparison; validity and the consequences of classification must be examined rather than assumed.

## 1920s–1930s — Human relations & the Hawthorne studies

Research at Western Electric helped direct attention to social relations and working conditions, influencing the human-relations movement. [Levitt & List, 2011](https://pubs.aeaweb.org/doi/10.1257/app.3.1.224).

**Psychology and work.** Informal groups, supervision and worker attitudes became central themes, though these ideas should not erase conflict, pay or material conditions.

**Measurement and analytics.** The studies became a lesson about observing work. Later analysis challenged popular accounts of the illumination results; observation alone does not establish causality.

## 1940s–1950s — Personnel, training & human factors

World War II expanded applied work on selection, training and equipment. Formal personnel functions and postwar research into work attitudes grew. [Oxford history](https://academic.oup.com/edited-volume/36330/chapter/318704027).

**Psychology and work.** Motivation, job satisfaction, learning and human-machine interaction joined aptitude and selection. Their measurement involves constructs, not directly observable facts.

**Measurement and analytics.** Job analysis, tests and surveys connected psychological theory with structured measurement; assessment quality depends on context.

## 1950s–1960s — Motivation, groups & organization

Researchers developed theories of motivation, leadership and group behavior; organizational development drew on group dynamics. In the US, Title VII of the 1964 Civil Rights Act addressed employment discrimination. [EEOC historical overview](https://www.eeoc.gov/bending-toward-justice-60-years-civil-rights-laws-protecting-workers-america).

**Psychology and work.** Needs, expectations, leadership and group processes offered competing explanations; no single theory fits every worker or context.

**Measurement and analytics.** Surveys and statistical associations became common, while employment discrimination raised questions about whose outcomes and opportunities were being measured.

## 1970s–1980s — Work design, rights & organizational behavior

Industrial psychology broadened into industrial-organizational psychology; job design, worker participation and the social context of organizations received greater attention. Personnel management increasingly connected with business strategy. [Oxford history](https://academic.oup.com/edited-volume/36330/chapter/318704027).

**Psychology and work.** Autonomy, feedback, meaningful work, commitment and stress helped shift attention from individual traits to the design of work.

**Measurement and analytics.** Questionnaires and administrative systems made larger studies possible, but measures of attitudes require reliability, construct validity and attention to unequal power.

## 1990s — Engagement, safety & strategic HR

Strategic HRM and organizational behavior grew alongside research on engagement and team learning. Kahn studied psychological conditions for engagement; Edmondson studied team psychological safety. [Edmondson, 1999](https://doi.org/10.2307/2666999).

**Psychology and work.** Meaningfulness, safety and availability are concepts in Kahn’s qualitative work; psychological safety is a shared team belief, not something to infer from a single personnel field.

**Measurement and analytics.** Survey research and multilevel analysis can examine individuals and teams, but cross-sectional relationships do not by themselves prove interventions work.

## 2000s — Evidence synthesis & digital HR

HR information systems and online workflows expanded; systematic reviews and meta-analyses brought findings across studies together. [Colquitt et al., 2001](https://pubmed.ncbi.nlm.nih.gov/11419803/).

**Psychology and work.** Organizational justice and the job demands–resources model connected fairness, work conditions and well-being to organizational outcomes.

**Measurement and analytics.** Meta-analysis, surveys and longitudinal methods provide different kinds of evidence. Digital traces are not direct measurements of emotions or intentions.

## 2010s — People analytics & predictive models

People analytics grew as organizations combined HR data, statistics and machine learning; a scoping review noted differing definitions and employer-centered value propositions. [People analytics scoping review](https://www.sciencedirect.com/science/article/pii/S0268401218301750).

**Psychology and work.** Turnover, engagement, learning and team research require theories of context, voice, motivation and fairness—not just a target label.

**Measurement and analytics.** Regression and predictive ML enable pattern finding, but leakage, missing outcomes, proxy discrimination and surveillance can make a model misleading or harmful.

## 2020–2026 — Foundation models & responsible research

Foundation models pretrained on many synthetic tabular tasks now compete on general tabular benchmarks. Their published performance does not establish value in workforce settings. [TabICLv2, ICML 2026](https://proceedings.mlr.press/v306/qu26a.html).

**Psychology and work.** Human experience, social structure and institutional context are not automatically captured by a vector representation. Employee voice and worker rights remain essential.

**Measurement and analytics.** A defensible evaluation needs prospective data, measured constructs, external and temporal tests, uncertainty, privacy protection and comparisons to strong baselines. PeopleFM has no workforce results yet.

## Psychological concepts for an evidence-first research program

| Construct and selected foundation | What it concerns | Research implication | Boundary |
|---|---|---|---|
| [Personal engagement: Kahn (1990)](https://doi.org/10.2307/256287) | Meaningfulness, safety and availability in relation to work roles | Develop a validated measurement strategy and consider context and level | Qualitative, theory-generating studies are not a universal predictive instrument |
| [Team psychological safety: Edmondson (1999)](https://doi.org/10.2307/2666999) | Shared beliefs about interpersonal risk and team learning | Analyze teams with appropriately collected, aggregated measures | An individual's activity log or turnover score does not measure team safety |
| [Job demands and resources: Demerouti et al. (2001)](https://pubmed.ncbi.nlm.nih.gov/11419809/) | Demands and resources in relation to exhaustion and disengagement | Assess work design with validated instruments and suitable study designs | A proxy such as overtime alone is not a burnout diagnosis |
| [Organizational justice: Colquitt et al. (2001)](https://pubmed.ncbi.nlm.nih.gov/11419803/) | Fairness of outcomes, procedures and interpersonal treatment | Evaluate worker experience and processes using multiple dimensions | Fairness in a statistical model is only one part of organizational justice |

A construct is a theoretical concept; an indicator is an operational measure. Whether an indicator measures the construct consistently and accurately requires validation across populations and contexts. Avoid treating demographic features or digital traces as psychological diagnoses. Data gathered under employer authority can be sensitive even when names are removed. Research should seek employee input, minimize collection, suppress small groups, and consider the risk that findings become surveillance or individual employment decisions.

## How this changes PeopleFM

1. **Formulate a theory and a question.** Specify the population, level (individual, team or organization), time and hypothesized mechanism before choosing a model.
2. **Design measurement.** Establish construct validity, data provenance, permissible collection and when each variable was available. Avoid labels derived from the predictors.
3. **Select the evaluation design.** A random split tests within-dataset prediction; it is not external transfer or causal evidence. Repeated people require grouped or temporal splits, with uncertainty that respects clustering.
4. **Compare useful alternatives.** Test interpretable and task-specific baselines, pretrained models and any justified shared representation under comparable partitions and budgets.
5. **Interpret with workers and context.** Examine calibration, subgroup performance where appropriate, privacy and the limits of data. Present aggregate findings only under a suitable governance protocol.

## Literature limitations and follow-up

This map prioritizes landmark examples rather than a complete genealogy. Future review should add labor and organizational histories from Asia, Africa, Latin America and Indigenous perspectives; the influence of colonialism, gender, race and worker movements; competing theories of motivation; psychometrics and measurement invariance; organizational interventions and causal evidence; platform work and algorithmic management. Record search dates, databases, inclusion rules and study-level quality before calling the review systematic. The PeopleFM benchmark has not validated these theories or demonstrated workforce model performance.

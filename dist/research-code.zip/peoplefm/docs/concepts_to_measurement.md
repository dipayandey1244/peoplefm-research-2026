# From people concepts to responsible analytics

This is a practical research map, not a diagnostic tool. All constructs require valid measures, contextual knowledge and worker participation; no single field or prediction is a psychological diagnosis.

| Concept | Organizational question | Measurement approach | Main limitation |
|---|---|---|---|
| Opportunity and internal mobility | Are people able to see and pursue relevant opportunities? | Aggregate applications, offers, transfers and exposure among eligible groups; survey perceived access | Access and application do not measure ability or indicate that workers wished to move |
| Learning and development | Is learning accessible and useful? | Eligibility, voluntary uptake, accessible learning time and feedback; prespecified follow-up outcomes | Participation may reflect scheduling, manager support or selection, not program effect |
| Engagement | How do people experience and invest themselves in their roles? | Validated surveys and qualitative feedback grounded in a clear construct | Survey response bias and managerial pressure; avoid individual inference |
| Psychological safety | Can team members speak up and learn? | Validated team-level measures with adequate group size and context | The construct is contextual and relational; no proxy or digital trace is a direct measure |
| Fairness and voice | Are outcomes and processes experienced as fair? | Evaluate outcome, procedural, interpersonal and informational dimensions; protect feedback channels | Statistical parity is not a complete account of organizational justice |
| Well-being and work design | Are demands, resources and safety conditions appropriate? | Survey burden, workload indicators and safety measures in a worker-informed design | Work intensity and well-being are multidimensional; no HR field is a burnout diagnosis |
| Prediction and uncertainty | Can a model help answer a narrowly defined aggregate question? | Compare held-out performance, calibration, cost and uncertainty with a simple baseline | Random split results do not show causation, fairness or transfer |

Sources: [Kahn (1990)](https://doi.org/10.2307/256287), [Edmondson (1999)](https://doi.org/10.2307/2666999), [Demerouti et al. (2001)](https://pubmed.ncbi.nlm.nih.gov/11419809/), [Colquitt et al. (2001)](https://pubmed.ncbi.nlm.nih.gov/11419803/), and [Diep & Horváthová (2025)](https://journals.sagepub.com/doi/full/10.1177/01672533251355886). Evidence is context-dependent, and some associations are not causal.

# Case study: evaluating access to internal mobility and learning in a large bank

**PROPOSED educational scenario. Not a study conducted at JPMorganChase.** No JPMorganChase employee data, internal plans, or results were accessed. The scenario is designed to be relevant to a leader of HR and people analytics at a large financial institution. JPMorganChase's [2025 annual report](https://www.jpmorganchase.com/content/dam/jpmc/jpmorgan-chase-and-co/investor-relations/documents/annualreport-2025.pdf) describes investments in internal mobility, training and upskilling. It does not state that this scenario or experiment was adopted.

## The decision

A people analytics leader wants to know whether improved access to career information and protected learning time helps employees pursue internal opportunities, while safeguarding staffing and employee experience. The intervention is an **organization-level offer**—not a model selecting individuals. A worker may decline to participate without penalty. Before launch, consult employees and representatives and review labor, privacy, model-risk and jurisdiction-specific employment obligations.

## Hypothesis and measures

Prespecify the target population, geography, role families, observation window, eligibility and local data permissions. Examples of aggregate measures: proportion able to access learning time; voluntary learning uptake; internal application and transfer rates among eligible employees; employee-reported opportunity and workload measured with validated questions; staffing coverage; accessibility and distribution across relevant groups where collection and analysis are lawful. Define denominators and outcome timing before analysis. Internal applications reflect both interest and available opportunities; they do not directly measure skill, motivation or the quality of a career outcome. If rates are descriptive, do not label differences impacts.

## Design

If feasible and approved, randomize comparable business units to receive a voluntary, inclusive learning-time and career-information package now versus a later rollout. Establish the randomization unit and prespecified treatment period, account for clustered inference and uneven sizes, and protect against spillovers. A delayed rollout or no-intervention comparison must be ethically and operationally approved; do not promise randomization is always possible. If randomization is infeasible, use a prespecified observational comparison, explain selection bias and parallel-trends assumptions before proposing difference-in-differences, and perform sensitivity analyses. No estimates can be produced without authorized data and an actual protocol.

## Role of models

The published PeopleFM experiments test TabICLv2 and baseline models on publicly sourced tabular prediction tasks; they do not evaluate an intervention, internal mobility or this bank. If an aggregate workforce forecast is contemplated, assess whether it is needed, compare simple baselines, document feature availability, protect held-out time periods and assess calibration and subgroup robustness lawfully. Never use the public benchmark scores as evidence of utility in the bank. Do not rank employees for hiring, promotion, compensation, termination or discipline.

## Guardrails and reporting

Obtain appropriate approvals and restrict access; minimize data, separate identity linkage from analysis, define a retention period and document re-identification, membership inference, logging and access threats. De-identification alone is not anonymity. Report group-level results with context-appropriate small-cell and complementary suppression, including checks against differencing across tables and releases. Protected attributes, where lawful and justified, should be handled separately for equity analysis, not presumed harmless when omitted from models. Review local law with qualified counsel; the [EEOC](https://www.eeoc.gov/sites/default/files/2024-04/20240429_What%20is%20the%20EEOCs%20role%20in%20AI.pdf) notes that employment discrimination rules also apply to AI and automated tools. Provide worker feedback and contestation channels. The deliverable should state uncertainty, negative results and non-findings as well as costs and operational effects.

## Milestones

1. Define a worker-informed question and data rights; map availability and feature timing.
2. Audit quality and use aggregate descriptive baselines; agree on suppression and disclosure rules.
3. Preregister outcomes, evaluation design and decision criteria; secure approvals.
4. Run a controlled pilot with appropriate statistical and privacy review; report both employee and organizational outcomes.
5. Stop, revise or scale only after reviewing evidence, employee experience, costs and risks. This is a decision framework, not a measured claim or production recommendation.

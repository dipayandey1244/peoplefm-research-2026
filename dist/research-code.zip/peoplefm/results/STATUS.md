# Experiment status

| Work | Status | Evidence and limits |
|---|---|---|
| Six conventional models on IBM fictional attrition sample | EXECUTED | `ibm/summary.json` and `ibm_boosted/summary.json`; same held-out rows |
| TabICLv2 on IBM fictional attrition sample | EXECUTED | `ibm/tabicl.json`; one checkpoint ensemble member, CPU |
| Six conventional models on TabArena job-change intention | EXECUTED | `jobchange/summary.json`; 1,500-row stratified subsample, not official TabArena folds |
| TabICLv2 on TabArena job-change intention | EXECUTED | `jobchange/tabicl.json`; same sampled held-out rows, one ensemble member |
| Cross-organization transfer, temporal validation, cross-task transfer | BLOCKED | Suitable data and aligned protocols not yet available |
| Fairness and shift evaluation | BLOCKED | Requires appropriate legal basis, governance and adequately sized groups |
| Shared PeopleFM encoder and ablations | PROPOSED | Insufficient multi-task and temporal evidence to justify training |

No model is marked REPRODUCED. The fixed test has already been inspected and must not be repeatedly used for model selection. OpenML's dataset is a job-search intention target, not observed attrition. Original data provenance and timing are not independently verified. In the full OpenML table, 49 duplicate records and 20,733 missing cells were counted; in this fixed sample there were zero exact full-row duplicates and zero matching feature rows across its train/test split after dropping gender. Other leakage, selection bias, dependence and proxy discrimination remain possible. CIs are conditional on fitted models and observed test class proportions; they do not test model differences. Runtime varies by hardware and preprocessing measurement differs for TabICLv2. MLP search is small. Peak memory is not measured.

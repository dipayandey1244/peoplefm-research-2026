# PeopleFM — research scaffold

This is an offline research scaffold, not a validated foundation model. Two exploratory dataset comparisons have been executed; see `research/experimental_results.md` and `results/STATUS.md`. See [limitations](docs/limitations.md), [review](research/literature_review.md), [HR and psychology history](research/hr_psychology_analytics_history.md), [dataset registry](datasets/registry.yaml), and [article](research/article.md). The empty workspace contained no prior application.

## Reproduce

Use Python 3.10+ with numpy, pandas and scikit-learn; see `results/smoke/summary.json` for actual versions used. From this directory:

```sh
python -m pip install -e .
python -m unittest discover -s tests
python -m peoplefm.benchmarks.run --config configs/benchmark.json
```

The last command requires the fictional IBM CSV at `datasets/raw/ibm.csv`, acquired separately from the source after reviewing its terms. It performs a stratified held-out split and repeated CV tuning of preprocessing and model parameters inside training, then evaluates test once. Configuration uses JSON to avoid a YAML dependency. Preprocessing is inside each fold; threshold is fixed at 0.5. All outputs are local. Do not run on sensitive employee records without an approved protocol. Files in `results/smoke` are a software test on a non-workforce dataset; the config and script reproduce it with sklearn's bundled data. Search space and costs are deliberately limited, and missing models are explicitly blocked.

To repeat the non-workforce integration run, use `python experiments/smoke.py` after installation.

The static research site lives in `website/dist/`; serve it using `python -m http.server 8000 --directory website/dist` and visit localhost:8000. It does not execute experiments or transmit data. To run experiments use the command above.

## Executed exploratory comparisons

The website and `research/experimental_results.md` show local comparisons on the fictional IBM sample and a 1,500-row stratified sample of the OpenML TabArena job-change-intention dataset. They are not the papers' full evaluation protocols. See `results/STATUS.md` for completed and blocked work. `experiments/prepare_tabarena.py` prepares the sample from the OpenML ARFF file; `configs/jobchange.json` drives the conventional models; `experiments/tabicl_compare.py --config configs/jobchange.json` runs the official pretrained checkpoint. These scripts require optional packages `tabicl`, `xgboost`, `lightgbm`, `catboost` and their native libraries; `requirements-benchmark.txt` records observed versions. Access the data and checkpoint from their cited sources. For repeatability, never alter test membership while comparing models.

## Practical research guide

See `docs/concepts_to_measurement.md` for ways to define organizational psychology constructs, and `docs/banking_case_study.md` for a clearly hypothetical, worker-informed study design relevant to a large bank. No JPMorganChase data or internal findings were used.

An executable audit produces dataset-level metadata only (small target distributions receive complementary suppression):

```sh
python experiments/audit_dataset.py --file datasets/raw/ibm.csv --target Attrition --min-group 20 --output results/ibm/aggregate_audit.json
```

Suppression is not a guarantee of anonymity. Before running on actual employee records, use an approved protocol and review whether even aggregate outputs are safe to release. Unit tests cover complementary suppression and small datasets.

import unittest
import numpy as np
from peoplefm.benchmarks.run import metrics, interval, build
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_breast_cancer
import pandas as pd
class BenchmarkTests(unittest.TestCase):
    def test_metrics_and_intervals(self):
        y=np.array([0,0,1,1]); p=np.array([.1,.4,.6,.9]); m=metrics(y,p)
        self.assertEqual(m['roc_auc'],1); self.assertEqual(m['recall'],1)
        self.assertEqual(len(interval(y,p,20,42)['brier']),2)
    def test_pipeline_fit(self):
        d=load_breast_cancer(as_frame=True); X=d.data.iloc[:100].copy(); X.iloc[0,0]=np.nan
        model,_=build('logistic',42); model.fit(X,d.target.iloc[:100]); self.assertEqual(model.predict_proba(X[:3]).shape,(3,2))
if __name__=='__main__': unittest.main()

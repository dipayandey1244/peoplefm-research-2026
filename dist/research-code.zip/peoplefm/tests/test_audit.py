import importlib.util
import tempfile
import unittest
from pathlib import Path
import pandas as pd
spec=importlib.util.spec_from_file_location('audit_dataset',Path(__file__).resolve().parents[1]/'experiments'/'audit_dataset.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
class AuditTest(unittest.TestCase):
    def test_complementary_suppression(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'data.csv'; pd.DataFrame({'target':['a']*29+['b']}).to_csv(p,index=False)
            result=module.audit(p,'target',20)
            self.assertIsNone(result['target_counts'])
            self.assertEqual(result['rows'],30)
    def test_refuses_small_dataset(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'data.csv'; pd.DataFrame({'target':['a']}).to_csv(p,index=False)
            with self.assertRaises(ValueError): module.audit(p,'target',20)
if __name__=='__main__': unittest.main()

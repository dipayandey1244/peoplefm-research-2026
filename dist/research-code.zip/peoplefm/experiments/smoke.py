"""Software integration check only. Not a workforce experiment."""
from pathlib import Path
from sklearn.datasets import load_breast_cancer
from peoplefm.benchmarks.run import run
p=Path('work/smoke_breast_cancer.csv'); p.parent.mkdir(exist_ok=True)
d=load_breast_cancer(as_frame=True).frame; d.to_csv(p,index=False)
c={'dataset':str(p),'target':'target','positive_label':1,'drop_columns':[], 'models':['logistic','random_forest','mlp'], 'test_size':0.2,'seed':42,'cv_splits':3,'cv_repeats':1,'bootstrap_repeats':100,'output':'results/smoke','data_classification':'NON-WORKFORCE scikit-learn breast-cancer dataset; software smoke test only','save_predictions':False}
run(c)

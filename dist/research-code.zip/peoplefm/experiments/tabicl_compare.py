"""Add independently executed TabICLv2 to the exact held-out IBM partition."""
import json, time, hashlib, argparse
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from peoplefm.benchmarks.run import build,metrics,interval
from tabicl import TabICLClassifier
import importlib.metadata as md

parser=argparse.ArgumentParser(); parser.add_argument('--config',default='configs/benchmark.json'); args=parser.parse_args()
config=json.loads(Path(args.config).read_text()); data=pd.read_csv(config['dataset'])
y=(data[config['target']]==config['positive_label']).astype(int).to_numpy()
X=data.drop(columns=[config['target']]+config['drop_columns'],errors='ignore')
train,test=train_test_split(np.arange(len(y)),test_size=config['test_size'],stratify=y,random_state=config['seed'])
prep=build('logistic',config['seed'])[0].named_steps['prep']
trainx=prep.fit_transform(X.iloc[train]); testx=prep.transform(X.iloc[test]); trainx=trainx.toarray() if hasattr(trainx,'toarray') else trainx; testx=testx.toarray() if hasattr(testx,'toarray') else testx
model=TabICLClassifier(n_estimators=1, checkpoint_version='tabicl-classifier-v2-20260212.ckpt', device='cpu', n_jobs=2, random_state=config['seed'])
t=time.perf_counter(); model.fit(trainx,y[train]); fit=time.perf_counter()-t
t=time.perf_counter(); probs=model.predict_proba(testx)[:,1]; predict=time.perf_counter()-t
out={'model':'TabICLv2','status':'EXECUTED','metrics':metrics(y[test],probs),'bootstrap_95_ci':interval(y[test],probs,config['bootstrap_repeats'],config['seed']),'fit_seconds':fit,'test_inference_seconds':predict,'threshold':0.5,'checkpoint':'tabicl-classifier-v2-20260212.ckpt','package_version':md.version('tabicl'),'n_estimators':1,'device':'cpu','notes':'Single ensemble member; default published benchmark is not reproduced. One-hot preprocessing fitted on training only.'}
Path(config['output'],'tabicl.json').write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))

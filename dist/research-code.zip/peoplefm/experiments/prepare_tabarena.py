"""Prepare a fixed computationally bounded, stratified subsample; not an official TabArena split."""
from pathlib import Path
import hashlib,json
import pandas as pd
from scipy.io import arff
from sklearn.model_selection import train_test_split
p=Path('datasets/raw/jobchange.arff')
lines=p.read_text().splitlines(); columns=[line.split()[1] for line in lines if line.upper().startswith('@ATTRIBUTE ')]; start=next(i for i,line in enumerate(lines) if line.upper().strip()=='@DATA')+1
df=pd.read_csv(p,skiprows=start,names=columns,quotechar="'",na_values=['nan','?'])
target='LookingForJobChange'; print(df[target].value_counts().to_dict()); print(df.shape)
_, subset=train_test_split(df,test_size=1500,random_state=42,stratify=df[target]); subset.to_csv('datasets/raw/jobchange_sample.csv',index=False)
audit={'source':'https://www.openml.org/d/46935','task':'https://www.openml.org/t/363679','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_rows':len(df),'source_columns':len(df.columns),'source_duplicates':int(df.duplicated().sum()),'source_missing_cells':int(df.isna().sum().sum()),'label_counts':df[target].value_counts().to_dict(),'sample_method':'1500 rows stratified from complete data with seed 42; split into 1200 train and 300 test with seed 42; not official TabArena folds','data_license':'CC0 per OpenML dataset card','warning':'Provenance and event timing not independently verified. Target is job search intention, not observed attrition.'}
Path('results/jobchange').mkdir(parents=True,exist_ok=True);Path('results/jobchange/source_audit.json').write_text(json.dumps(audit,indent=2))

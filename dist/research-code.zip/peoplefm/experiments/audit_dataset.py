"""Aggregate dataset audit, not an employee scoring or decision tool.

Use only on data approved for offline research. Output may itself be sensitive:
review before sharing, and do not infer causation from aggregate statistics.
"""
import argparse
import hashlib
import json
from pathlib import Path
import pandas as pd


def suppress(n, minimum):
    return int(n) if n >= minimum else None


def audit(path, target, min_group=20):
    if min_group < 2:
        raise ValueError('min_group must be at least 2')
    source = Path(path)
    data = pd.read_csv(source)
    if target not in data:
        raise ValueError('Target column not found')
    total = len(data)
    if total < min_group:
        raise ValueError('Dataset is smaller than the suppression threshold')
    counts = data[target].fillna('<missing>').value_counts(dropna=False)
    # Complementary suppression: if one cell is hidden, suppress the entire
    # distribution so it cannot be derived from the grand total.
    class_counts = None if (counts < min_group).any() else {str(k): int(v) for k, v in counts.items()}
    # Dataset-level summaries only: do not output row-level data or column value counts.
    return {'sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
            'rows': total, 'columns': len(data.columns), 'target': target,
            'missing_cells': int(data.isna().sum().sum()),
            'duplicate_rows': int(data.duplicated().sum()),
            'target_counts': class_counts, 'suppression_threshold': min_group,
            'note': 'Counts only; no employee scores. Suppression does not eliminate re-identification risk.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--file', required=True)
    parser.add_argument('--target', required=True)
    parser.add_argument('--min-group', type=int, default=20)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    result = audit(args.file, args.target, args.min_group)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + '\n')
    print('Wrote aggregate audit to', out)


if __name__ == '__main__':
    main()
